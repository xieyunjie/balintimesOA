package org.jbpm.test.humantask.test.workitem.wsht;

import org.junit.Test;

public class BasicTaskServiceTest extends WSHumanTaskHandlerHornetQTest {

	@Test
	public void testSetUp(){
		System.out.println("Success");
	}
}
