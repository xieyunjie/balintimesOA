What's the BRMS?
----------------

* JBoss BRMS is an open source decision management platform that combines Business Rules Management and Complex Event Processing. It automates business decisions and makes that logic available to the entire business.

* JBoss BRMS uses a centralized repository where all resources are stored. T his ensures consistency, transparency, and the ability to audit across the business.



