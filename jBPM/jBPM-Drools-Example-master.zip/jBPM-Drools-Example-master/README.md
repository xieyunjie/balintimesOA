### jBPM ###

[jBPM quickstart](https://github.com/kylinsoong/jBPM-Drools-Example/blob/master/docs/jbpm-quickstarts.asciidoc)

[jBPM Approval Demo](https://github.com/kylinsoong/jBPM-Drools-Example/blob/master/docs/jBPM-approval.asciidoc)

[jBPM persistence](https://github.com/kylinsoong/jBPM-Drools-Example/blob/master/docs/jBPM-persist.asciidoc)


### Drools ###

[3 ways to load ksession](https://github.com/kylinsoong/jBPM-Drools-Example/blob/master/docs/drools-ksession.asciidoc)

[Demo for using KnowledgeAgent to get PKG from Guvnor](https://community.jboss.org/wiki/DemoForUsingKnowledgeAgentToGetPKGFromGuvnor)

