package org.drools.expert.stu03;

public class Alarm {

}
