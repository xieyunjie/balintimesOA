package org.drools.expert.stu06;

public class Bar {

}
