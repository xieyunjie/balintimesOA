package org.guvnor.test.project2;


public class Project2 {

	public static String getPrompt() {
		return "Prompt From Project2";
	}
	

}
