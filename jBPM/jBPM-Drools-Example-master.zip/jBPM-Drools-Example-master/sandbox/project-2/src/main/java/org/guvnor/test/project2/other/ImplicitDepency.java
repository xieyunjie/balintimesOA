package org.guvnor.test.project2.other;

import org.guvnor.test.project1.Project1;

public class ImplicitDepency {
	
	Project1 project;

	public Project1 getProject() {
		return project;
	}

	public void setProject(Project1 project) {
		this.project = project;
	}

}
