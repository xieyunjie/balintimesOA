package org.guvnor.test.project3;


public class Project3 {

	public static String getPrompt() {
		return  "Prompt From Project3";
	}

}
