package org.guvnor.test.project1;

public class Project1 {

	public static String getPrompt() {
		return "Prompt From Project1";
	}

}
